package com.mongodb.phonebook100;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phonebook100ApplicationTests {

	@Test
	void contextLoads() {
	}

}
